package com.movieflix.auth.utils;

public record ChangePassword(String password, String repeatPassword) {
}
